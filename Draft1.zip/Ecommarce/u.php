<!DOCTYPE html>
<html>
<head>
	<title></title>
	<p1>update</p1>
</head>
<body>

		<fieldset>
			

			<form method="get" action=" ">
			
			User Name: <input type="text" name="id" placeholder="text"> <br/>
				
				User Name: <input type="text" name="name" placeholder="text"> <br/>
				Password : &nbsp&nbsp<input type="password" name="pass" value="pass"><br/><br/>
				
	
				
				
				
				
						   &nbsp&nbsp &nbsp&nbsp &nbsp&nbsp &nbsp&nbsp <input type="submit" name="submit" value="update"> &nbsp&nbsp &nbsp&nbsp
						   
						   
			</form>
		</fieldset>
</body>
</html>

<?php
$host= "localhost";
	 $dbUsername="root";
	 $dbPassword="";
	 $dbname= "data1";
	 $conn = mysqli_connect($host, $dbUsername, $dbPassword);
    mysqli_select_db($conn, $dbname);
	
	if(isset($_GET['submit']))
		
	{
		$id= $_GET['id'];
		$name= $_GET['name'];
		$pass= $_GET['pass'];
		
	//UPDATE re2 SET name='$name', pass='$pass' where id='$id' 	
		
	$q1= "DELETE FROM `re2` WHERE id='$id' ";
	$q2=mysqli_query($conn,$q1);
	
	if($q2)
	{
	echo '<script type="text/javascript"> alert("updated") </script>';
	}
	
	else
	{echo '<script type="text/javascript"> alert("Not_updated") </script>';}
	}
	
	
		
		
	
	
	
	
	

	
	

?>