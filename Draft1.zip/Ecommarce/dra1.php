<?php


$host= "localhost";
	 $dbUsername="root";
	 $dbPassword="";
	 $dbname= "data1";
 
 $conn = mysqli_connect($host, $dbUsername, $dbPassword) ;
  mysqli_select_db( $conn , $dbname)  ;
	
	$q= "Select * from re1 ";
	$d1= mysqli_query($conn, $q);
	$rowc= mysqli_num_rows($d1);



?>
<table>
<tr>
<thead>
Picture 
</thead>
</tr>
<?php


for($i=1; $i<=$rowc; $i++)
{
	$r =mysqli_fetch_array($d1);

	?>
	<tr> 
	<td> Picture: <img src=  "re1/<?php echo $r['file']  ?>" height= '200px' width='200px'   /> </td>
	
	
	</tr>
	<?php

	}


?>
<table>
