<?php

//$name= $_POST['user'];
//$pass= $_POST['pass'];

       
	   require('tcpdf\fpdf.php'); 
      $pdf = new FPDF();  
      $pdf->AddPage();   
	  
      $pdf->SetFont('Arial', 'B', 20);  
	  $pdf->Cell(100,20,"GRETTINGS","0","1","C");
	  
	
	  
	  $host= "localhost";
	 $dbUsername="root";
	 $dbPassword="";
	 $dbname= "data1";
 
  
  $conn = mysqli_connect($host, $dbUsername, $dbPassword);
    mysqli_select_db($conn, $dbname);
	$q1= "Select * from re2 ";
$r1= mysqli_query($conn, $q1);

 //$pdf->setLeftMrgins(20);
	  $pdf->SetFont('Arial', 'B', 12);  
	  $pdf->Cell(20,10,"id",1,0,'C');
	  $pdf->Cell(20,10,"name",1,0,'C');
	   $pdf->Cell(20,10,"pass",1,0,'C');
	    $pdf->Cell(20,10,"gender",1,0,'C');
		  $pdf->ln();
		


	while($row=mysqli_fetch_array($r1))
	{
	
		$pdf->SetFont('Arial', '', 12); 
$pdf->Cell(20,10,$row['id'],1,0,'C');		
	  $pdf->Cell(20,10,$row['name'],1,0,'C');
	  $pdf->Cell(20,10,$row['pass'],1,0,'C');
	  $pdf->Cell(20,10,$row['gender'],1,0,'c');
	  $pdf->ln();
	  
	}

	  
	   $pdf->Output();
      



?>