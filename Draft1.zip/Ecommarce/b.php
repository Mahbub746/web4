<?php

$name= $_POST['user'];
$pass= $_POST['pass'];

       
	   require('tcpdf\fpdf.php'); 
      $pdf = new FPDF();  
      $pdf->AddPage();  
	  
      $pdf->SetFont('Arial', 'B', 28);  
	  $pdf->Cell(40,10,'GRETTINGS');
	  $pdf->Ln(15);
	  $pdf->Cell(40,10,'NUMBER');
	  $pdf->Ln(15);
	  $pdf->SetFont('Arial', 'B', 10);  
      $pdf->Cell(40,10,$name);
	  $pdf->Ln(5);
	  //$pdf-> In();
	  $pdf->Cell(40,10,$pass);
	  $pdf->Ln(5);
	  //$pdf-> In();
	   $pdf->Output();
      



?>