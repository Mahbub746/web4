<?php


 
 session_start();
 
 
	 $host= "localhost";
	 $dbUsername="root";
	 $dbPassword="";
	 $dbname= "data1";
 
  
  $conn = mysqli_connect($host, $dbUsername, $dbPassword);
    mysqli_select_db($conn, $dbname);
	
  $name = $_POST['user'];
  $pass = $_POST['pass']; 
  $gender = $_POST['gender'];  
 
 $s1= "Select * from re2 where name = '$name'" ; 
 $r1 = mysqli_query($conn, $s1);
 $num1=mysqli_num_rows($r1);
 
 
  
	  
		  if($num1== 1 || $name== ""|| $pass== "" || $gender== "" )
	  {
		  echo '<script type="text/javascript"> alert("INVALID USER OR PASSWORD") </script>';
		  //header('location: signup.php');
		  
	  }
	  
	  
	  else
		  {
	 
	 $r2= "insert into re2(name , pass , gender) values('$name','$pass', '$gender')";
	 mysqli_query($conn, $r2);
	  
 header('location: login.php');
  //echo '<script type="text/javascript"> alert("INVALID USER OR PASSWORD") </script>';
	 
 }
  
  
  
 
 
?>