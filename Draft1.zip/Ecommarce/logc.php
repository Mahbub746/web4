
<?php


 
 session_start();
 
 
	 $host= "localhost";
	 $dbUsername="root";
	 $dbPassword="";
	 $dbname= "data1";
 
  
  $conn = mysqli_connect($host, $dbUsername, $dbPassword);
    mysqli_select_db($conn, $dbname);
	
  $name = $_POST['user'];
  $pass = $_POST['pass']; 
  
 
 $s1= "Select * from re2 where name = '$name' && pass = '$pass'" ; 
 $r1 = mysqli_query($conn, $s1);
 $num1=mysqli_num_rows($r1);
 
 
  
	  
		  if( $name== ""|| $pass== "" || $num1 !=1   )
	  {
		  echo '<script type="text/javascript"> alert("INVALID USER OR PASSWORD") </script>';
		  //header('location: signup.php');
		  
	  }
	  
	  
	  else
		  {
	 
	 $r2= "Select * from re2 where name = '$name' && pass = '$pass' " ; 
	 $s2=mysqli_query($conn, $r2);
	 $num2=mysqli_num_rows($s2);
	 
	 if( $num2== 1 )
	 {
	  
 $_SESSION['abc'] = '123';
	  header('location: home1.php');
	 }
 }
  
  
  
 
 
?>