<?php


 
 session_start();
 
 
	 $host= "localhost";
	 $dbUsername="root";
	 $dbPassword="";
	 $dbname= "data1";
 
  
  $conn = mysqli_connect($host, $dbUsername, $dbPassword);
    mysqli_select_db($conn, $dbname);
	
  $name= $_POST['user'];
  $pass= $_POST['pass'];
//$gender= $_POST['gender'];  
 
 $s1= "Select * from re2 where name = '$name' && pass = '$pass' "; 
 $r1 = mysqli_query($conn, $s1);
 $num1=mysqli_num_rows($r1);
  if($num1 == 1)
  {
	  //$_SESSION['abc'] = '123';
	  header('location: home1.php');
  }
  
  
 
 else
 {
	 header('location: signup.php');
 }
?>