<?php
	session_start();
	
	if($_SESSION['abc']=='123')
	{
		echo "welcome to profile page";
		
	}else{
		header("location: login.php");

	}
	
?>

	