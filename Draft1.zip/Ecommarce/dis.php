<?php

$con=mysqli_connect("localhost","root","");
mysqli_select_db( $con,"data1");

$q= mysqli_query($con,"select * from re1");
$rowc= mysqli_num_rows($q);
?>


<table >
Downloads<br/><br/>

<?php

for($i=1; $i<=$rowc; $i++)
{
	$r =mysqli_fetch_array($q);
}
	
	
?>



<tr>
  
  <td> Picture: <img src ="re1/<?php echo $r["file"]  ?>" height= '200px' width='200px'/> <br/><br/></td>
</tr>


<?php




?>

</table >

