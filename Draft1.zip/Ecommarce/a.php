<!DOCTYPE html>
<html>
<head>
	<title>LOGIN</title>
	<p1>LOGIN</p1>
</head>
<body>

		<fieldset>
			

			<form method="post" action="b.php">
				
				User Name: <input type="text" name="user" value="text:"> <br/>
				Password : &nbsp&nbsp<input type="text" name="pass" value="pass:"><br/><br/>
				
				
				
				<input type="submit" name="submit"  value="Create PDF" />  
				
				
					
						  
						   
			</form>
		</fieldset>
</body>
</html>


