<?php

	if(isset($_POST['submit'])){

		$username = $_POST['username'];
		$password = $_POST['password'];
		$gender   = $_POST['gender'];


		if($username == "" || $password == "" || $gender == ""){

			//echo "invalid submission";
			header("location: reg.php");

		}else{

			$myfile = fopen("user.txt", 'a');
			$data = $username."|".$password."|".$gender."\r\n";
			fwrite($myfile, $data);
			fclose($myfile);

			header("location: login.php");

		}
	}

?>