<html>
<head>
	<title>SIGNUP</title>
	<p1>SIGNUP</p1>
</head>
<body>

		<fieldset>
			

			<form  method="post" action="regc.php" >
				
				User Name: <input type="text" name="user" value="text"> <br/>
				Password : &nbsp <input type="password" name="pass" value="pass"><br/><br/>
				
				Gender:&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp <Select name="gender" />
				<option value="">Select</option>
				<option value="Male">Male</option>
				<option value="Female">Female</option>
				<option value="Others">Others</option>
				</Select><br/><br/>
				
				
		<input type="radio" id="male" name="" value=""> <label for="male">x</label><br>
<input type="radio" id="female" name="" value=""> <label for="female">y</label><br>
<input type="radio" id="other" name="" value=""> <label for="other">z</label>	<br/><br/> 



				
				
				
				
						   <input type="submit" name="Signup" value="Signup"><br/>
						   
			</form>
		</fieldset>
</body>
</html>