<?php
	session_start();
	
	if($_SESSION['abc']=='123')
	{
		echo "<a href='logout.php'>logout </a> <br/><br/>";
		$myfile = fopen("user.txt", 'r');
		$data = fread($myfile, filesize("user.txt"));
		$arr = explode("|", $data);
		fclose($myfile);

		echo "Username: ".$arr[0]."<br/>";
		echo "Password: ".$arr[1]."<br/>";
		echo "Gender: ".$arr[2]."<br/>";
	}else{
		header("location: login.php");

	}
	
?>

	