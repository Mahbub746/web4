<?php

$con=mysqli_connect("localhost","root","");
mysqli_select_db( $con,"data1");
if(isset($_POST['submit']))
 {
	 //$f_name = $_POST ['f_name'] ;
	 $file = $_FILES['myfile']['name'];
	 
	 
	 $tmp_loc = $_FILES['myfile']['tmp_name'];
	 $file_store = "re1/".$file ;
	 $file1= explode(".", $file);
	 $ext= $file1[1];
	 $all= array( "jpg","png", "pdf" );
	 
	if(in_array($ext ,$all ))
	{
		move_uploaded_file($tmp_loc, $file_store);
		mysqli_query($con,"insert into re1(file)values('$file')");
		header('location: download.php');
	}
		
	
	 
 }

?>


<html>
<body>
<form enctype = "multipart/form-data" action="up.php"  method="post" >

   File upload:&nbsp&nbsp <input type="file" name="myfile"  placeholder="Browse" ><br/><br/>
				&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp <input type="submit" name="submit" value="upload"><br/><br/>


				</form>
</body>
</html>