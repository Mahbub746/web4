

<!DOCTYPE html>
<html>
<head>
	<title>REGISTRATION</title>
</head>
<body>
		<fieldset>
			<legend>Registration</legend>

			<form method="post" action="regCheck.php">

				User Name: <input type="text" name="username"><br/>
				Password : <input type="password" name="password"><br/>
				Gender   : <input type="radio" name="gender" value="male">Male
						   <input type="radio" name="gender" value="female">Female
						   <input type="radio" name="gender" value="other">Other <br/>
						   <input type="submit" name="submit" value="Submit">
			</form>
		</fieldset>
</body>
</html>